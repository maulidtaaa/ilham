const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

resizeCanvas();
window.addEventListener("resize", resizeCanvas);

let angle = 0;
const speed = 0.01;
const text = "haloo ilhammm sayanggg";

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "#ff00cc";
  ctx.shadowColor = "#ff00cc";
  ctx.shadowBlur = 25;
  ctx.font = "14px Arial";

  const cx = canvas.width / 2;
  const cy = canvas.height / 2;

  for (let i = 0; i < 200; i++) {
    const t = i * 0.1 + angle;

    const x = 16 * Math.pow(Math.sin(t), 3);
    const y =
      13 * Math.cos(t)
      - 5 * Math.cos(2 * t)
      - 2 * Math.cos(3 * t)
      - Math.cos(4 * t);

    ctx.fillText(
      text,
      cx + x * 15,
      cy - y * 15
    );
  }

  angle += speed;
  requestAnimationFrame(draw);
}

draw();
